/* Module de modélisation des règles de jeu */
