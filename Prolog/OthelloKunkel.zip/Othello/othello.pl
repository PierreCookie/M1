/* Module principal */

lanceJeu() :-